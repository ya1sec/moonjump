import { Hook } from '@oclif/config';
export declare function checkTos(options: any): void;
declare const hook: Hook.Init;
export default hook;
